from multiprocessing.managers import BaseManager

class QueueManager(BaseManager):
	pass