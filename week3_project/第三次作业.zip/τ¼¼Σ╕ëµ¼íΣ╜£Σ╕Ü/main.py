#import GraphStat.NetworkBuilder.node
import GraphStat
#from GraphStat import *

node_list = GraphStat.NetworkBuilder.node.init_node(r'/Volumes/HIKVISION/何熙1908/大三上课程/现代程序设计/第三次作业/newmovies.txt')
GraphStat.NetworkBuilder.node.print_node(node_list)