import time
@profile
def test_time():
	for i in range(100):
		a=[1]*(10**4)
		b=[2]*(10**4)
		pass
test_time()