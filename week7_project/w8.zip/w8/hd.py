import heartrate; 
heartrate.trace(browser=True)

for i in range(1000):
	pass